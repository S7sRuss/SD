module Samples where

import Syntax 

--  decl x = var(0) in x := !x + 1

a = Decl "x" (Var (Num 0) None) 
             (Assign (Id "x" None) (Add (Deref (Id "x" None) None) (Num 1)) None) None

-- decl x = var(0) in while not (!x = 10) do x := !x + 1 ; !x ;;

a' = Decl "x" (Var (Num 0) None) 
              (Seq (While (Not (Equal (Deref (Id "x" None) None) (Num 10))) 
                          (Assign (Id "x" None) (Add (Deref (Id "x" None) None) (Num 1)) None)) 
                   (Deref (Id "x" None) None)) None 

-- if 0 = 0 then 1+1 else 2+2 ;;

a_if = If (Equal (Num 0) (Num 0)) (Add (Num 1) (Num 1)) (Add (Num 2) (Num 2)) IntType

-- if not (0 = 0) then 1+1 else 2+2 ;;

a_if' = If (Not (Equal (Num 0) (Num 0))) (Add (Num 1) (Num 1)) (Add (Num 2) (Num 2)) IntType

-- decl x = var(0) in decl s = var(1) in while not (!x = 10) do (x := !x + 1; s := !s * !x) ; !s ;;

fact = Decl "x" (Var (Num 0) None) 
       (Decl "s" (Var (Num 1) None) 
       (Seq 
       (While (Not (Equal (Deref (Id "x" None) None) (Num 10))) 
              (Seq 
               (Assign (Id "x" None) (Add (Deref (Id "x" None) None) (Num 1)) None)
               (Assign (Id "s" None) (Mul (Deref (Id "s" None) None) 
                                          (Deref (Id "x" None) None)) None)))
       (Deref (Id "s" None) None)) None) None

-- decl f = fun x:int -> x+x+1 in f 1 ;;

f = Decl "f" (Fun "x" IntType (Add (Id "x" None) 
                              (Add (Id "x" None) (Num 1))) None) 
             (Call (Id "f" None) (Num 1) None) None

-- decl y = 0 in decl f = fun x:int -> x+x+y in f 1 ;;

f' = Decl "y" (Num 3) 
     (Decl "f" 
       (Fun "x" IntType (Add (Id "x" None) (Add (Id "x" None) (Id "y" None))) None) 
       (Call (Id "f" None) (Num 1) None) None) None

-- decl y = 1 in decl z = 2 in decl f = fun x:int -> x+x+y in f 1 ;;

f'' = Decl "y" (Num 1)
      (Decl "z" (Num 2)
     (Decl "f" 
       (Fun "x" IntType (Add (Id "x" None) (Add (Id "z" None) (Id "y" None))) None) 
       (Call (Id "f" None) (Num 1) None) None) None) None

-- decl f = fun y:int -> fun x:int -> x+y in f 2 3 ;;

h = Decl "f" 
    (Fun "y" IntType (Fun "x" IntType (Add (Id "x" None) (Id "y" None)) None) None)
    (Call (Call (Id "f" None) (Num 0) None) (Num 1) None) None

-- decl f = fun y:int -> fun x:int -> x+y in decl g = f 2 in g 3 ;;

h' = Decl "f" 
     (Fun "y" IntType (Fun "x" IntType (Add (Id "x" None) (Id "y" None)) None) None)
     (Decl "g" (Call (Id "f" None) (Num 2) None)    
               (Call (Id "g" None) (Num 3) None) None) None

-- decl g = fun x:int -> x+1 in g 1 ;;

g = Decl "g" (Fun "x" IntType (Add (Id "x" None) (Num 1)) None) (Call (Id "g" None) (Num 1) None) None

-- decl w = 3 in decl y = 1 in decl g = fun x:int -> x + y in (fun z:int -> y + g (z+w)) 1 ;;

g' = Decl "w" (Num 3)
     (Decl "y" 
       (Num 1)
       (Decl "g" 
       (Fun "x" IntType (Add (Id "x" None) (Id "y" None)) None)
       (Call 
         (Fun "z" IntType (Add (Id "y" None) 
                               (Call (Id "g" None) 
                                     (Add (Id "z" None) (Id "w" None)) None)) None) 
         (Num 1) None) None)
       None) None

-- decl f = fun x:int -> var (x) in decl v = f 1 in v := 2; !v ;;

v = Decl "f" 
         (Fun "x" IntType (Var (Id "x" None) None) None)
         (Decl "v" (Call (Id "f" None) (Num 1) None)
                   (Seq (Assign (Id "v" None) (Num 2) None)
                        (Deref (Id "v" None) None)) None) None

-- decl f = fun x:int -> x+1 in (fun f: int => int -> f 1) (f) ;;

ff = Decl "f" (Fun "x" IntType (Add (Id "x" None) (Num 1)) None)
              (Call 
              (Fun "f" (FunType IntType IntType) 
                       (Call (Id "f" None) (Num 1) None) None)
              (Id "f" None) None) None
